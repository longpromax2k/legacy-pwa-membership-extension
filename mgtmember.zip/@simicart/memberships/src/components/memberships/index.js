import React from 'react';
import { fullPageLoadingIndicator } from '@magento/venia-ui/lib/components/LoadingIndicator';
import { useGetProducts } from '../../talons/useGetProducts';
import { mergeClasses } from '@magento/venia-ui/lib/classify';
import { shape, string } from 'prop-types';

import defaultClasses from './index.module.css';

// Membership items
const MembershipItem = props => {
    return (
        <div className={defaultClasses.membershipItem}>
            <div className={defaultClasses.featuredItem}>
                <img
                    src="https://membership-demo.mageplaza.com/media/mageplaza/membership/default/featured.png"
                    alt="featured"
                />
                <span>
                    <strong>Featured</strong>
                </span>
            </div>
            <div className={defaultClasses.membershipItemTitle}>
                <h1>{props.name}</h1>
            </div>
            <div className={defaultClasses.membershipItemContent}>
                <img
                    className={defaultClasses.membershipItemImage}
                    src={props.imageurl}
                    alt={props.label}
                />
                <div
                    className={defaultClasses.description}
                    dangerouslySetInnerHTML={{ __html: props.desc }}
                />
            </div>

            <form onSubmit={handleAddToCart}>
                <select
                    className={defaultClasses.selectMenu}
                    name="duration"
                    id="subs-duration"
                >
                    <option value={'$' + props.price + ' / month'}>
                        ${props.price} / month
                    </option>
                    <option value={'$' + props.price * 12 + ' / month'}>
                        ${props.price * 12} / year
                    </option>
                </select>
                <button type="submit" className={defaultClasses.addToCart}>
                    Add to cart
                </button>
            </form>
        </div>
    );
};

// handle add to cart action
const handleAddToCart = e => {
    e.preventDefault();
    alert('Added to cart: ' + e.target.elements.duration.value);
};

// Main component
const MembershipPage = props => {
    const { mbshipData, mbshipLoading, mbshipError } = useGetProducts();
    const classes = mergeClasses(defaultClasses, props.classes);

    try {
        if (mbshipLoading) return <fullPageLoadingIndicator />;
        else if (mbshipError) return <div>{mbshipError.message}</div>;
        else {
            return (
                <>
                    <div className={classes.root}>
                        {mbshipData.products.items.map(item => {
                            return (
                                <MembershipItem
                                    key={item.uid}
                                    name={item.name}
                                    desc={item.description.html}
                                    imageurl={item.image.url}
                                    label={item.image.label}
                                    price={item.mpmembership_price_fixed}
                                />
                            );
                        })}
                    </div>
                </>
            );
        }
    } catch (error) {
        return <div>{mbshipError}</div>;
        console.error(error);
    }
};

MembershipPage.propTypes = {
    classes: shape({ root: string })
};
MembershipPage.defaultProps = {};
export default MembershipPage;
